-- Create the database
CREATE DATABASE IF NOT EXISTS farm_equipment_sharing_db;

-- Use the database
USE farm_equipment_sharing_db;

-- Create the Users table
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(255) NOT NULL,
    Email VARCHAR(255) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL,
    UserType ENUM('farmer', 'owner') NOT NULL
);

-- Insert sample data into the Users table
INSERT INTO Users (FullName, Email, Password, UserType) VALUES
('John Doe', 'johndoe@example.com', 'password', 'farmer'),
('Jane Smith', 'janesmith@example.com', 'password', 'owner');

-- Create the Equipment table
CREATE TABLE IF NOT EXISTS Equipment (
    EquipmentID INT AUTO_INCREMENT PRIMARY KEY,
    EquipmentName VARCHAR(100) NOT NULL,
    Description TEXT,
    Availability ENUM('available', 'unavailable') NOT NULL,
    PricePerHour DECIMAL(10, 2) NOT NULL
);

-- Create the Bookings table
CREATE TABLE IF NOT EXISTS Bookings (
    BookingID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    EquipmentID INT NOT NULL,
    BookingDate DATE NOT NULL,
    DurationInHours INT NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (EquipmentID) REFERENCES Equipment(EquipmentID)
);

-- Create the FarmSharePractices table
CREATE TABLE IF NOT EXISTS FarmSharePractices (
    PracticeID INT AUTO_INCREMENT PRIMARY KEY,
    Practice TEXT NOT NULL
);

-- Insert sample farm share practices
INSERT INTO FarmSharePractices (Practice) VALUES
    ('Rotational grazing for livestock'),
    ('Companion planting for crop diversity'),
    ('Water-efficient irrigation techniques');

-- Create the BookingRentals table
CREATE TABLE IF NOT EXISTS BookingRentals (
    RentalID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    EquipmentID INT NOT NULL,
    EquipmentName VARCHAR(100) NOT NULL,
    RentalDate DATE NOT NULL,
    RentalDurationInHours INT NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (EquipmentID) REFERENCES Equipment(EquipmentID)
);

-- Insert sample data into the BookingRentals table
INSERT INTO BookingRentals (UserID, EquipmentID, EquipmentName, RentalDate, RentalDurationInHours) VALUES
(1, 1, 'Tractor', '2024-05-01', 8), -- John Doe rents Tractor for 8 hours on May 1, 2024
(1, 2, 'Plow', '2024-05-03', 6); -- John Doe rents Plow for 6 hours on May 3, 2024
